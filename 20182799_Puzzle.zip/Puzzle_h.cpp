﻿#define _CRT_SECURE_NO_WARNINGS

#include <bangtal>
using namespace bangtal;

#include <cstdlib>
#include <ctime>

#include <Windows.h>

ScenePtr scene;
ObjectPtr game_board[9], game_original[9];
ObjectPtr start;

TimerPtr timer;
float animationTime = 0.01f;
int mixCount = 100;

TimerPtr fall_back_timer;


int blank;

int game_index(ObjectPtr piece) {
	for (int i = 0; i < 9; i++)
		if (game_board[i] == piece) return i;
	return -1;	//INVALID PEICE

	auto fall_back_timer = Timer::create(60.f);
	showTimer(fall_back_timer);
	fall_back_timer->setOnTimerCallback([&](TimerPtr)->bool {
		showMessage("Time Over");
		return true;
		});
	fall_back_timer->start();
}

int index_to_x(int index) {
	return 500 + 170 * (index % 3);
}

int index_to_y(int index) {
	return 520 - 169 * (index / 3);
}

void game_move(int index) {
	auto piece = game_board[index];
	game_board[index] = game_board[blank];
	game_board[index]->locate(scene, index_to_x(index), index_to_y(index));
	game_board[blank] = piece;
	game_board[blank]->locate(scene, index_to_x(blank), index_to_y(blank));
	blank = index;
}

bool check_move(int index) {
	if (blank % 3 > 0 && index == blank - 1) return true;	// 제일 첫 번째 열이 아니면, index가 blank의 왼쪽에 있으면 TRUE 리턴.
	if (blank % 3 < 2 && index == blank + 1) return true;	//네번째 열이 아니면, 123열이면 index가 blank가 오른쪽에 있으면 true.
	if (blank / 3 > 0 && index == blank - 3) return true;	//첫번째 행이 아닐때,(줄) index가 blank 위에 있으면 treu 리턴.
	if (blank / 3 < 2 && index == blank + 3) return true;	//마지막 행이 아닐때, 그 위의 행일떄 index가 blank 아래 있으면 true.

	return false;
}

int random_move() {
	int index = rand() % 9;
	while (!check_move(index)) {
		index = rand() % 9;
	}
	return index;
}

void start_game() {

	mixCount = 100;

	timer->set(animationTime);
	timer->start();


	blank = 8;	//restart 했을 때 퍼즐 빈칸이 2개로 늘어나는데, 이 코드 때문인듯
	game_board[blank]->hide();

	start->hide();


}

bool check_end() {
	for (int i = 0; i < 9; i++) {
		if (game_board[i] != game_original[i]) return false;
	}
	return true;
}

void end_game() {
	game_board[blank]->show();
	showMessage("성공!");
	fall_back_timer->stop();
}

void init_game() {
	scene = Scene::create("키스해링 퍼즐", "Images/back.png");

	char path[20];
	for (int i = 0; i < 9; i++) {
		sprintf(path, "Images/%d.jpg", i + 1);

		game_board[i] = Object::create(path, scene, index_to_x(i), index_to_y(i));
		game_board[i]->setOnMouseCallback([&](auto piece, auto x, auto y, auto action)->bool {
			// piece-->index
			int index = game_index(piece);
			if (check_move(index)) {
				game_move(index);

				if (check_end()) {
					end_game();
				}
			}

			return true;	
			});
		game_original[i] = game_board[i];
	}

	start = Object::create("Images/start.png", scene, 630, 150);
	start->setScale(0.2f);
	start->setOnMouseCallback([&](auto, auto, auto, auto)->bool {
		start_game();
		return true;
		});

	timer = Timer::create(animationTime);
	timer->setOnTimerCallback([&](auto)->bool {
		game_move(random_move());

		mixCount--;
		if (mixCount > 0) {
			timer->set(animationTime);
			timer->start();
		}


		auto fall_back_timer = Timer::create(60.f);
		showTimer(fall_back_timer);
		fall_back_timer->setOnTimerCallback([&](TimerPtr)->bool {
			showMessage("Time Over");

			start->setImage("Images/restart.png");
			start->setScale(0.5f);
			start->show();

			return true;
		});
		fall_back_timer->start();


		auto endButton = Object::create("Images/end.png", scene, 200, 500);
		endButton->setScale(0.5f);
		endButton->setOnMouseCallback([&](ObjectPtr endButton, int x, int y, MouseAction action)->bool {
		
			endGame();

			return true;
			});


		auto HelpButton = Object::create("Images/help.png", scene, 200, 200);
		HelpButton->setScale(0.4f);
		HelpButton->setOnMouseCallback([&](ObjectPtr HelpButton, int x, int y, MouseAction action)->bool {
			showMessage("퍼즐 맞추기 게임입니다.\n 빈칸 옆에 있는 퍼즐을 누르면 퍼즐이 빈칸으로 이동합니다.\n 제한된 시간 내에 퍼즐을 모두 제자리에 맞추면 게임에서 승리하고,\n 제한시간을 초과하면 패배합니다.\n");

			return true;
		});

		return true;
		});



	startGame(scene);

}

int main() {
	srand((unsigned int)time(NULL));

	setGameOption(GameOption::GAME_OPTION_INVENTORY_BUTTON, false);
	setGameOption(GameOption::GAME_OPTION_MESSAGE_BOX_BUTTON, false);

	init_game();

	return 0;
}

